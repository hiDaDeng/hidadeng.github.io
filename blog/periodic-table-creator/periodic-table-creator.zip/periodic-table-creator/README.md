# 任务周期表生成器

[**click demo**](https://www.innerdoc.com/periodic-table-demo/)

这个**周期表生成器**的想法是创建一个关于 [自然语言处理任务周期表](https://www.innerdoc.com/periodic-table-of-nlp-tasks/) 的博客。 在 Streamlit 的帮助下并受到此 Bokeh [图库示例](https://docs.bokeh.org/en/latest/docs/gallery/periodic.html) 的启发，它成为了一个动态的创建者，可以根据您的元素周期表进行定制 ！

大邓的作用仅仅是将其汉化，没有做布局上的新创新。

<br>

## 演示

[**Open the demo app!**](https://www.innerdoc.com/periodic-table-demo/)

下面是自定义的**任务周期表**示例。 在这种情况下：对于自然语言处理任务！

![alt text](img/periodic-table-generator-customize-content.png)


## 安装&运行

打开命令行(终端),
```
pip3 install streamlit==1.8.1
pip3 install bokeh==2.4.1


#切换至项目文件夹periodic-table-creator
cd periodic-table-creator

#运行streamlit
streamlit run periodic_table_creator.py
```

此时在命令行中会出现

![](img/terminal.png)

点击Local URL对应的链接，或者将该链接复制粘贴到浏览器，即可访问。

![](img/firstrun.png)

<br>

## 导入数据

创建自己特有的**任务周期表**需要导入自由的csv数据。可以[点击这里] (periodic-table-creator/periodic_nlp.csv) 下载并查看数据格式，或者运行案例时， 点击按钮"Edit CSV text" 查看示例数据格式。

- 表的字符名(列名): ``atomicnumber;group;period;symbol;elementname;groupname;color;url;excerpt``
- csv文件的分隔符使用英文格式下的 ``;``或``,``
- csv文件使用utf-8编码

![](img/periodic-table-generator-load-content.png)

<br>



