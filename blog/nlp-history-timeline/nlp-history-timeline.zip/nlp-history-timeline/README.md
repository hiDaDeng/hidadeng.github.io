使用streamlit制作自然语言处理发展时间线页面

Streamlit_NLP_timeline.png


## 说明
这个案例使用[Streamlit](https://streamlit.io) 和 [TimelineJS](http://timeline.knightlab.com/) 制作， 通过时间线方式展示自然语言处理领域发展。大家可以将其改造为公司发展时间线、人生里程碑时间线等等。

<br>



## 下载&运行

下载，解压nlp-history-timeline.zip文件夹

```
#切换到nlp-history-timeline
cd nlp-history-timeline

#安装需要的包
pip3 install -r requirements.txt

#运行timeline_app.py
streamlit run timeline_app.py
```



## 使用方式

- [点击打开案例网站](https://www.innerdoc.com/nlp-timeline-demo/)

下面是网页的一个时间点

![alt text](demo-timeline.png "An example of the timeline with events for the history of Natural Language Processing!")

<br>

你也可以浏览的原始数据文件，格式为json。下图可以看到json的是由

- 36个字典，即36个时间点
- 每个字典中有很多字段，如url图片链接、headline、year年份、text简介等。

![alt text](demo-data.png "An example of the timeline data.")



<br>

