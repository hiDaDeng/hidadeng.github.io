# Screenshot of this startpage

![Screenshot](preview.webp)

__Main features:__
- Search engine selection
- Quick access to your favorite websites
- Card-like list navigation
