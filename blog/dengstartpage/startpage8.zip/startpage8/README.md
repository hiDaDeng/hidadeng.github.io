# Screenshot of this startpage

![Screenshot](preview.webp)

__Main features:__
- Search engine selection
- Quick access to your favorite websites
- Time-based greeting

_Big thanks to u/Teiem1 from reddit for refactoring the script.js of this startpage!_
